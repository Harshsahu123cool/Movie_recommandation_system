from flask import Flask, render_template, request
import pandas as pd
import numpy as np
from sklearn.preprocessing import MultiLabelBinarizer
from scipy.sparse.linalg import svds
from scipy.sparse import csr_matrix

app = Flask(__name__)

# Load data
movies = pd.read_csv('D:/movie_recommandation/movies.csv')
rating = pd.read_csv('D:/movie_recommandation/ratings.csv')

# Preprocess genres
movies['genres'] = movies['genres'].str.split('|')
mlb = MultiLabelBinarizer()
genres_encoded = mlb.fit_transform(movies['genres'])
genre_data = pd.DataFrame(genres_encoded, columns=mlb.classes_)
movies = movies.join(genre_data)

# User-Movie Matrix and SVD Model
user_movie_matrix = rating.pivot_table(index='userId', columns='movieId', values='rating').fillna(0)
R = user_movie_matrix.values
R_sparse = csr_matrix(R)
k = 20
U, sigma, Vt = svds(R_sparse, k=k)
sigma = sigma[::-1]
U = U[:, ::-1]
Vt = Vt[::-1, :]
sigma_k = np.diag(sigma)
R_pred = np.dot(np.dot(U, sigma_k), Vt)

@app.route('/')
def index():
    return render_template('index.html', recommendations=None, error_message=None)

@app.route('/genre')
def genre_page():
    return render_template('genre.html', genres=mlb.classes_, recommendations=None, error_message=None)

@app.route('/rating')
def rating_page():
    return render_template('rating.html', recommendations=None, error_message=None)

@app.route('/recommend_by_title', methods=['POST'])
def recommend_by_title():
    movie_title = request.form['movie_title']
    user_rating = request.form.get('rating', type=float)
    matched_movies = movies[movies['title'].str.contains(movie_title, case=False, na=False)]

    if matched_movies.empty:
        return render_template('index.html', recommendations=None, error_message="Movie title not found. Please try again.")

    movie_id = matched_movies.iloc[0]['movieId']

    if movie_id not in user_movie_matrix.columns:
        return render_template('index.html', recommendations=None, error_message="Movie not available for recommendation.")

    movie_index = user_movie_matrix.columns.get_loc(movie_id)
    predicted_ratings = R_pred[:, movie_index]
    recommendations = [(user_movie_matrix.index[i], predicted_ratings[i]) for i in range(len(predicted_ratings))]
    recommendations.sort(key=lambda x: x[1], reverse=True)

    top_users = [user_id for user_id, _ in recommendations[:10]]
    top_movies = rating[rating['userId'].isin(top_users)]['movieId'].value_counts().head(10).index.tolist()
    final_recs = movies[movies['movieId'].isin(top_movies)][['title']].values.flatten().tolist()

    return render_template('index.html', recommendations=[(title, '') for title in final_recs], error_message=None)

@app.route('/recommend_by_genre', methods=['POST'])
def recommend_by_genre():
    genre = request.form['genre']
    user_id = int(request.form['user_id'])

    if user_id not in user_movie_matrix.index:
        return render_template('genre.html', genres=mlb.classes_, recommendations=None, error_message="User ID not found.")

    user_index = user_movie_matrix.index.get_loc(user_id)
    predicted_ratings = R_pred[user_index]

    genre_movies = movies[movies[genre] == 1]
    genre_movie_ids = genre_movies['movieId'].tolist()
    rated_movie_ids = rating[rating['userId'] == user_id]['movieId'].tolist()

    recs = [(movie_id, predicted_ratings[user_movie_matrix.columns.get_loc(movie_id)])
            for movie_id in genre_movie_ids if movie_id in user_movie_matrix.columns and movie_id not in rated_movie_ids]

    recs_sorted = sorted(recs, key=lambda x: x[1], reverse=True)
    recommendations = [(movies[movies['movieId'] == movie_id]['title'].values[0], round(score, 2))
                       for movie_id, score in recs_sorted[:10]]

    return render_template('genre.html', genres=mlb.classes_, recommendations=recommendations, error_message=None)

@app.route('/recommend_by_rating', methods=['POST'])
def recommend_by_rating():
    user_id = int(request.form['user_id'])

    if user_id not in user_movie_matrix.index:
        return render_template('rating.html', recommendations=None, error_message="User ID not found.")

    user_index = user_movie_matrix.index.get_loc(user_id)
    predicted_ratings = R_pred[user_index]

    rated_movie_ids = rating[rating['userId'] == user_id]['movieId'].tolist()
    unrated_movie_ids = [mid for mid in user_movie_matrix.columns if mid not in rated_movie_ids]

    recommendations = [(movies[movies['movieId'] == movie_id]['title'].values[0],
                        round(predicted_ratings[user_movie_matrix.columns.get_loc(movie_id)], 2))
                       for movie_id in unrated_movie_ids if movie_id in movies['movieId'].values]

    recommendations.sort(key=lambda x: x[1], reverse=True)
    return render_template('rating.html', recommendations=recommendations[:10], error_message=None)

if __name__ == '__main__':
    app.run(debug=True)